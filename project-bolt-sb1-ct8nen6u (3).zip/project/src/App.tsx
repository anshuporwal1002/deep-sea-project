import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { Waves, Anchor, Fish, AlertTriangle, Info, Globe2, BarChart3, Brain, Shield, Target } from 'lucide-react';

const creatures = [
  {
    name: "Giant Squid Collective",
    description: "Advanced beings utilizing ocean currents to combat climate change and restore marine ecosystems.",
    image: "https://images.unsplash.com/photo-1545671913-b89ac1b4ac10?auto=format&fit=crop&w=800",
    threat: "Low",
    solution: "Carbon capture technology and ocean current manipulation",
  },
  {
    name: "Bioluminescent Council",
    description: "Masters of deep-sea energy systems, offering sustainable alternatives to fossil fuels.",
    image: "https://images.unsplash.com/photo-1544552866-d3ed42536cfd?auto=format&fit=crop&w=800",
    threat: "Medium",
    solution: "Renewable energy from bioluminescence",
  },
  {
    name: "Abyssal Guardians",
    description: "Ancient protectors of marine biodiversity, sharing knowledge of underwater ecosystem restoration.",
    image: "https://images.unsplash.com/photo-1580019542155-247062e19ce4?auto=format&fit=crop&w=800",
    threat: "High",
    solution: "Marine ecosystem rehabilitation and species preservation",
  }
];

const impacts = [
  {
    title: "Environmental Impact",
    description: "Reducing ocean pollution by 40% through advanced filtration systems",
    icon: Globe2,
    color: "text-green-400",
  },
  {
    title: "Economic Benefits",
    description: "Creating sustainable ocean-based industries worth $500B annually",
    icon: BarChart3,
    color: "text-blue-400",
  },
  {
    title: "Technology Transfer",
    description: "Sharing advanced deep-sea technologies for sustainable development",
    icon: Brain,
    color: "text-purple-400",
  },
  {
    title: "Marine Protection",
    description: "Establishing protected marine zones covering 30% of ocean territory",
    icon: Shield,
    color: "text-yellow-400",
  }
];

function App() {
  const [selectedCreature, setSelectedCreature] = useState(null);
  
  const { ref: heroRef, inView: heroInView } = useInView({ triggerOnce: true });
  const { ref: creaturesRef, inView: creaturesInView } = useInView({ triggerOnce: true });
  const { ref: impactRef, inView: impactInView } = useInView({ triggerOnce: true });

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 to-black text-white">
      {/* Hero Section */}
      <header ref={heroRef} className={`relative h-screen flex items-center justify-center overflow-hidden transition-opacity duration-1000 ${heroInView ? 'opacity-100' : 'opacity-0'}`}>
        <div className="absolute inset-0 bg-blue-950/50 z-10" />
        <div className="relative z-20 text-center px-4">
          <div className="flex justify-center mb-6">
            <Waves className="w-16 h-16 animate-pulse" />
          </div>
          <h1 className="text-6xl font-bold mb-4">Deep Sea Solutions</h1>
          <p className="text-xl text-blue-200 mb-8">Partnering with oceanic intelligence to solve Earth's greatest challenges</p>
          <div className="flex flex-col items-center gap-4">
            <div className="bg-blue-900/30 backdrop-blur-sm rounded-lg p-4 max-w-lg">
              <p className="text-sm text-blue-300">Google Solution Challenge 2025</p>
              <p className="text-lg mt-2">Addressing UN SDGs 13 & 14: Climate Action and Life Below Water</p>
            </div>
            <div className="flex items-center justify-center gap-4 mt-4">
              <Anchor className="w-6 h-6 animate-bounce" />
              <span className="text-blue-300">Explore Solutions</span>
            </div>
          </div>
        </div>
      </header>

      {/* Creatures Section */}
      <section ref={creaturesRef} className={`max-w-6xl mx-auto px-4 py-20 transition-all duration-1000 ${creaturesInView ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <h2 className="text-4xl font-bold mb-12 text-center">Our Aquatic Partners</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {creatures.map((creature) => (
            <div 
              key={creature.name}
              className="bg-blue-900/30 rounded-lg overflow-hidden backdrop-blur-sm hover:transform hover:scale-105 transition-transform cursor-pointer group"
              onClick={() => setSelectedCreature(creature)}
            >
              <div className="relative">
                <img 
                  src={creature.image} 
                  alt={creature.name}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                  <p className="text-sm text-blue-200">{creature.solution}</p>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-semibold">{creature.name}</h3>
                  <div className={`flex items-center gap-2 ${
                    creature.threat === "High" ? "text-red-400" :
                    creature.threat === "Medium" ? "text-yellow-400" :
                    "text-green-400"
                  }`}>
                    <AlertTriangle className="w-4 h-4" />
                    <span className="text-sm">{creature.threat}</span>
                  </div>
                </div>
                <p className="text-blue-200">{creature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Impact Section */}
      <section ref={impactRef} className={`bg-blue-950/50 py-20 transition-all duration-1000 ${impactInView ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <Target className="w-12 h-12 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">Sustainable Development Goals Impact</h2>
            <p className="text-blue-200 max-w-2xl mx-auto">
              Our partnership with deep sea intelligence directly addresses critical environmental challenges
              while promoting sustainable development and innovation.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {impacts.map((impact) => (
              <div key={impact.title} className="bg-blue-900/30 backdrop-blur-sm rounded-lg p-6 hover:transform hover:scale-105 transition-transform">
                <impact.icon className={`w-8 h-8 ${impact.color} mb-4`} />
                <h3 className="text-xl font-semibold mb-2">{impact.title}</h3>
                <p className="text-blue-200 text-sm">{impact.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex justify-center mb-6">
            <Fish className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-bold mb-4">Join the Initiative</h2>
          <p className="text-blue-200 mb-8">
            Be part of this groundbreaking collaboration between surface and deep-sea intelligence.
          </p>
          <div className="flex items-center justify-center gap-4 text-sm">
            <Info className="w-4 h-4" />
            <span>Solution Challenge submission opening soon</span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/50 py-6">
        <div className="max-w-6xl mx-auto px-4 text-center text-blue-400 text-sm">
          <p>© 2025 Deep Sea Diplomatic Relations | Google Solution Challenge Entry</p>
        </div>
      </footer>
    </div>
  );
}

export default App;