import React, { useState } from 'react';
import { Waves, Anchor, Fish, AlertTriangle, Info } from 'lucide-react';

const creatures = [
  {
    name: "Giant Squid",
    description: "Ancient guardians of the deep, now seeking surface alliances.",
    image: "https://images.unsplash.com/photo-1545671913-b89ac1b4ac10?auto=format&fit=crop&w=800",
    threat: "Low",
  },
  {
    name: "Anglerfish Coalition",
    description: "Bringing their bioluminescent wisdom to illuminate our darkest hours.",
    image: "https://images.unsplash.com/photo-1544552866-d3ed42536cfd?auto=format&fit=crop&w=800",
    threat: "Medium",
  },
  {
    name: "Abyssal Leviathans",
    description: "Mysterious beings from the hadal zones, offering ancient knowledge.",
    image: "https://images.unsplash.com/photo-1580019542155-247062e19ce4?auto=format&fit=crop&w=800",
    threat: "High",
  }
];

function App() {
  const [selectedCreature, setSelectedCreature] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 to-black text-white">
      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-blue-950/50 z-10" />
        <div className="relative z-20 text-center px-4">
          <div className="flex justify-center mb-6">
            <Waves className="w-16 h-16 animate-pulse" />
          </div>
          <h1 className="text-6xl font-bold mb-4">They're Coming</h1>
          <p className="text-xl text-blue-200 mb-8">The depths have decided to rise. Our oceanic visitors await.</p>
          <div className="flex items-center justify-center gap-4">
            <Anchor className="w-6 h-6 animate-bounce" />
            <span className="text-blue-300">Scroll to discover</span>
          </div>
        </div>
      </header>

      {/* Creatures Section */}
      <section className="max-w-6xl mx-auto px-4 py-20">
        <h2 className="text-4xl font-bold mb-12 text-center">Known Visitors</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {creatures.map((creature) => (
            <div 
              key={creature.name}
              className="bg-blue-900/30 rounded-lg overflow-hidden backdrop-blur-sm hover:transform hover:scale-105 transition-transform cursor-pointer"
              onClick={() => setSelectedCreature(creature)}
            >
              <img 
                src={creature.image} 
                alt={creature.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xl font-semibold">{creature.name}</h3>
                  <div className={`flex items-center gap-2 ${
                    creature.threat === "High" ? "text-red-400" :
                    creature.threat === "Medium" ? "text-yellow-400" :
                    "text-green-400"
                  }`}>
                    <AlertTriangle className="w-4 h-4" />
                    <span className="text-sm">{creature.threat}</span>
                  </div>
                </div>
                <p className="text-blue-200">{creature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-blue-950/50 py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex justify-center mb-6">
            <Fish className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-bold mb-4">Prepare for Contact</h2>
          <p className="text-blue-200 mb-8">
            Our deep sea visitors are approaching. Stay informed about their arrival.
          </p>
          <div className="flex items-center justify-center gap-4 text-sm">
            <Info className="w-4 h-4" />
            <span>More information coming soon</span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/50 py-6">
        <div className="max-w-6xl mx-auto px-4 text-center text-blue-400 text-sm">
          <p>© 2025 Deep Sea Diplomatic Relations</p>
        </div>
      </footer>
    </div>
  );
}

export default App;